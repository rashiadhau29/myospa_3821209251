// import mysql from 'mysql2';


// const db = mysql.createConnection({
//   host: 'localhost',
//   user: 'root',
//   password: 'root',
//   database: 'Myospaz',
// });

// db.connect((err) => {
//   if (err) {
//     console.error('MySQL connection error:', err);
//     return;
//   }
//   console.log('Connected to MySQL database.');
// });

// export default db;




// import mysql from 'mysql2';


// const db = mysql.createConnection({
//   host: 'localhost',
//   user: 'root',
//   password: 'root',
//   database: 'myospaz'
// });


// db.connect((err) => {
//   if (err) {
//     console.error('MySQL connection error:', err);
//     return;
//   }
//   console.log('Connected to MySQL database.');
// });


// const dbPromise = {
//   query: (sql, values) => {
//     return new Promise((resolve, reject) => {
//       db.query(sql, values, (err, results) => {
//         if (err) return reject(err);
//         resolve(results);
//       });
//     });
//   }
// };

// export default dbPromise;

import mysql from 'mysql2';

const db = mysql.createPool({
  host: "127.0.0.1",
  user: "root",
  password: "",
  database: "myospaz",
  // port: 3307,
});

// Test Connection
db.getConnection((err, connection) => {
  if (err) {
    console.error("MySQL connection error:", err);
  } else {
    console.log("✅ Connected to MySQL database.");
    connection.release();
  }
});

const dbPromise = {
  query: (sql, values) => {
    return new Promise((resolve, reject) => {
      db.query(sql, values, (err, results) => {
        if (err) return reject(err);
        resolve(results);
      });
    });
  }
};

export default dbPromise;
